package com.coindirect.recruitment.dto;

import lombok.Data;

@Data
public class RequestBookingDto {

    String name;
    String row;
    String column;
}
