package com.coindirect.recruitment.dto;

import lombok.Data;

@Data
public class DeleteDto {
    String bookingId;
}
